// Arrow button functionality
const arrowOne = document.getElementById("arrow-1");
const arrowTwo = document.getElementById("arrow-2");

arrowOne.addEventListener("click", ()=>{
  document.getElementById("main").scrollIntoView({behavior: 'smooth', block:'start'});
});

arrowTwo.addEventListener("click", ()=>{
  document.getElementById("about").scrollIntoView({behavior:'smooth', block:'start'});
});

const orderButton = document.getElementById("booking-initialization");

orderButton.addEventListener("click", ()=>{
  document.getElementById("booking").style.display = document.getElementById("booking").style.display === "none" ? "block" : "none";
  document.getElementById("booking").scrollIntoView({behavior: 'smooth', block:'start'});
})

document.querySelector('.tc-v2-embeddable-trigger-el').addEventListener('click', function() {
  document.getElementById('thrivecart-container').style.display = 'block';
});


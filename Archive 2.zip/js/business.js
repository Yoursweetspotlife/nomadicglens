const orderButton = document.getElementById("booking-initialization-3");

orderButton.addEventListener("click", ()=>{
  document.getElementById("booking-3").style.display = document.getElementById("booking-3").style.display === "none" ? "block" : "none";
  document.getElementById("booking-3").scrollIntoView({behavior: 'smooth', block:'start'});
})

document.querySelector('.tc-v2-embeddable-trigger-el').addEventListener('click', function() {
  document.getElementById('thrivecart-container').style.display = 'block';
});

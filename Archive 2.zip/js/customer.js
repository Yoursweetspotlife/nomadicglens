const orderButton = document.getElementById("booking-initialization-2");

orderButton.addEventListener("click", ()=>{
  document.getElementById("booking-2").style.display = document.getElementById("booking-2").style.display === "none" ? "block" : "none";
  document.getElementById("booking-2").scrollIntoView({behavior: 'smooth', block:'start'});
})

document.querySelector('.tc-v2-embeddable-trigger-el').addEventListener('click', function() {
  document.getElementById('thrivecart-container').style.display = 'block';
});
